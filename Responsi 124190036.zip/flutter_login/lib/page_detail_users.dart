import 'package:flutter/material.dart';
import 'package:flutter_login/Controllers/api_data_source.dart';
import 'package:flutter_login/models/detail_user_model.dart';

class PageDetailUsers extends StatefulWidget {
  PageDetailUsers({super.key, required this.dataUsers});
  int dataUsers;

  @override
  State<PageDetailUsers> createState() => _PageDetailUsersState();
}

class _PageDetailUsersState extends State<PageDetailUsers> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: FutureBuilder(
        future: ApiDataSource.instance.loadDetailUser(widget.dataUsers),
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          if (snapshot.hasError){
            return _buildErrorSection();
          }
          if (snapshot.hasData){
            DetailUserModel userData = DetailUserModel.fromJson(snapshot.data);
            return   Card(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 100,
                    child:// Image.network(userData.avatar!),
                    Image.network(userData.data!.avatar.toString()),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("${userData.data!.firstName!} ${userData.data!.lastName!}")
                    ],
                  ),
                ],
              ),
            );
          }
          return _buildLoadingSection();
        },
      ),
    );



  }

  Widget _buildErrorSection(){
    return const Text('Eror');
  }

  Widget _buildLoadingSection(){
    return const Center(
      child: CircularProgressIndicator(),
    );
  }
}