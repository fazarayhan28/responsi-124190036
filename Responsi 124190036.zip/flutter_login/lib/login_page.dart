import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {

  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String username = "";
  String password = "";

  bool isLogin = false;
  bool isPasswordNotVisible = false;

  late TextEditingController usernameController;
  late TextEditingController passwordController;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    usernameController = TextEditingController();
    passwordController = TextEditingController();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    usernameController.dispose();
    passwordController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // IMAGE
            Padding(
              padding: const EdgeInsets.all(10),
              child: Center(
                child: Image.asset(
                  'assets/images/task.png',
                  height: 200,
                ),
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Welcome back',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.blue,
              ),
            ),
            const SizedBox(height: 10),
            const Text('Log in and enjoy our features!'),
            const SizedBox(height: 30),
            TextField(
              controller: usernameController,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(6)),
                ),
              ),
              // onChanged: (value) {
              // username = value;
              // },
            ),
            const SizedBox(height: 20),
            TextField(
              controller: passwordController,
              keyboardType: TextInputType.visiblePassword,
              obscureText: isPasswordNotVisible,
              decoration: InputDecoration(
                labelText: 'Password',
                border: const OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(6)),
                ),
                suffixIcon: Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: IconButton(
                    onPressed: () {
                      setState(() {
                        isPasswordNotVisible = !isPasswordNotVisible;
                      });
                    },
                    icon: (isPasswordNotVisible)
                      ? const Icon(Icons.visibility_off)
                    : Icon(Icons.visibility),
                  ),
                ),
              ),
              //  onChanged: (value) {
              //   password = value;
              // },
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {},
                  child: const Text('Forgot Password ?'),
                ),
              ],
            ),
            const SizedBox(height: 25),
            SizedBox(
              height: 40,
              width: MediaQuery.of(context).size.width,
              child: ElevatedButton(
                onPressed: () {
                    String message = "";
                    username = usernameController.text;
                    password = passwordController.text.trim();
                    if (username == "flutter" && password == "1234"){
                      setState(() {
                        message = "login berhasil";
                        isLogin = true;
                      });
                    }
                    else {
                    message = "login gagal";
                    isLogin = false;
                    }
                    // membuat snackbar
                    var snackBar = SnackBar(
                      content: Text(message),
                      backgroundColor: (isLogin) ? Colors.green : Colors.red,
                    );
                    // menampilkan snackbar
                    ScaffoldMessenger.of(context).showSnackBar(snackBar);
                    },
                child: const Text('Login'),
              ),
            ),
            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('Don\'t have account ?'),
                TextButton(
                  onPressed: () {},
                  child: const Text('Register'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
